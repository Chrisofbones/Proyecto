/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

import datos.ArriendoDAO;
import datos.ServicioDAO;
import entidades.Arriendo;
import entidades.Servicio;
import entidades.Detallearriendo;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.table.DefaultTableModel;


/**
 *
 * @author cristiangajardo
 */
public class ArriendoControl {
    private final ArriendoDAO DATOS;
    private Arriendo obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;
    private final ServicioDAO DATOSERV;

public ArriendoControl(){
        this.DATOS=new ArriendoDAO();
        this.DATOSERV=new ServicioDAO();
        this.obj=new Arriendo();
        this.registrosMostrados=0;
    }


 public DefaultTableModel listar(String texto,int totalPorPagina,int numPagina){
        List<Arriendo> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto,totalPorPagina,numPagina));
        
        String[] titulos={"Id","Usuario ID","Usuario","Cliente ID","Cliente","ubicacion","fecha","obs"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String[] registro = new String[8];
        SimpleDateFormat sdf=new SimpleDateFormat("dd/MM/yyyy");
        
        this.registrosMostrados=0;
        for (Arriendo item:lista){
            registro[0]=Integer.toString(item.getId());
            registro[1]=Integer.toString(item.getUsuarioId());
            registro[2]=item.getUsuarionombre();
            registro[3]=Integer.toString(item.getPersonaId());
            registro[4]=item.getPersonaNombre();
            registro[5]=item.getUbicacion();
            registro[8]=sdf.format(item.getFecha());
            registro[6]=item.getObs();
            
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }


public DefaultTableModel listarDetalle(int id){
        List<Detallearriendo> lista=new ArrayList();
        lista.addAll(DATOS.listarDetalle(id));
        
        String[] titulos={"ID","CODIGO","Servicio","hora","cantidad","total"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String[] registro = new String[8];
        
        for (Detallearriendo item:lista){
            registro[0]=Integer.toString(item.getId());
            registro[1]=item.getServiciocodigo();
            registro[2]=item.getServicionomnbre();
            registro[3]=item.getHora();
            registro[4]=Integer.toString(item.getCantidad());
            registro[7]=Double.toString(item.getTotal());            
            this.modeloTabla.addRow(registro);

        }
        return this.modeloTabla;
    }

public String insertar(int personaId, String ubicacion, Date fecha, String obs,DefaultTableModel modeloDetalles){
        if (DATOS.existe(personaId,ubicacion)){
            return "el cliente ya existe.";
        }else{
            obj.setUsuarioId(Variables.usuarioId);
            obj.setPersonaId(personaId);
            obj.setUbicacion(ubicacion);
            obj.setFecha(fecha);
            obj.setObs(obs);
            
            List<Detallearriendo> detalles = new ArrayList();
            int servicioId;
            String hora;
            int cantidad;
            double total;
            
            for (int i=0;i<modeloDetalles.getRowCount();i++){
                servicioId=Integer.parseInt(String.valueOf(modeloDetalles.getValueAt(i, 0)));
                hora=String.valueOf(modeloDetalles.getValueAt(i, 4));
                cantidad=Integer.parseInt(String.valueOf(modeloDetalles.getValueAt(i, 5)));
                total=Double.parseDouble(String.valueOf(modeloDetalles.getValueAt(i, 6)));
                detalles.add(new Detallearriendo(servicioId,cantidad,hora,total));
            }
            
            obj.setDetalles(detalles);
            
            if (DATOS.insertar(obj)){
                return "OK";
            }else{
                return "Error en el registro.";
            }
        }
    }


 public String anular(int id){
        if (DATOS.anular(id)){
            return "OK";
        }else{
            return "No se puede anular el registro";
        }
    }





}
