/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

import datos.PersonaDAO;
import entidades.Persona;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author cristiangajardo
 */
public class PersonaControl {
    private final PersonaDAO DATOS;
    private Persona obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;

public PersonaControl(){
        this.DATOS=new PersonaDAO();
        this.obj=new Persona();
        this.registrosMostrados=0;
    }

}
