/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package negocio;

import datos.RolDAO;
import datos.UsuarioDAO;
import entidades.Usuario;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author cristiangajardo
 */
public class UsuarioControl {
    private final UsuarioDAO DATOS;
    private final RolDAO DATOSROL;
    private Usuario obj;
    public int registrosMostrados;
    private DefaultTableModel modeloTabla;


public UsuarioControl(){
        this.DATOS=new UsuarioDAO();
        this.DATOSROL=new RolDAO();
        this.obj=new Usuario();
        this.registrosMostrados=0;
    }
 
public DefaultTableModel listar(String texto,int totalPorPagina,int numPagina){
        List<Usuario> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto,totalPorPagina,numPagina));
        
        String[] titulos={"Id","Rol ID","Rol","Usuario","Email","contraseña","Estado"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String estado;
        String[] registro = new String[7];
        
        this.registrosMostrados=0;
        for (Usuario item:lista){
            if (item.isActivo()){
                estado="Activo";
            } else{
                estado="Inactivo";
            }
            registro[0]=Integer.toString(item.getId());
            registro[1]=Integer.toString(item.getRolId());
            registro[2]=item.getRolnombre();
            registro[3]=item.getNombre();
            registro[4]=item.getemail();
            registro[5]=item.getContraseña();
            registro[6]=estado;
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }

 public String login(String email,String contraseña){
        String resp="0";
        Usuario usu=this.DATOS.login(email,this.encriptar(contraseña));
        if (usu!=null){
            if (usu.isActivo()){
                Variables.usuarioId=usu.getId();
                Variables.rolId=usu.getRolId();
                Variables.rolNombre=usu.getRolnombre();
                Variables.usuarioNombre=usu.getNombre();
                Variables.usuarioEmail=usu.getemail();
                resp="1";
            }else{
                resp="2";
            }
        }
        return resp;
    }

    private String encriptar(String contraseña) {
     
        return null;
     
    }

public String insertar(int RolId, String nombre, String email, String contraseña){
        if (DATOS.existe(email)){
            return "El registro ya existe.";
        }else{
            obj.setRolId(RolId);
            obj.setNombre(nombre);
            obj.setemail(email);
            obj.setContraseña(this.encriptar(contraseña));
            
            if (DATOS.insertar(obj)){
                return "OK";
            }else{
                return "Error en el registro.";
            }
        }
    }

public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }

 public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }

public int total(){
        return DATOS.total();
    }

}
