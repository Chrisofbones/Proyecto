/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author cristiangajardo
 */
public class Servicio {
    private int ids;
    private int categoriaId;
    private String categoriaNombre;
    private String codigo;
    private String nombre;
    private double Precioarriendo;
    private int stock;
    private String descripcion;
    private String imagen;
    private boolean activo;

    public Servicio() {
    }

    public Servicio(int ids, int categoriaId, String categoriaNombre, String codigo, String nombre, double Precioarriendo, int stock, String descripcion, String imagen, boolean activo) {
        this.ids = ids;
        this.categoriaId = categoriaId;
        this.categoriaNombre = categoriaNombre;
        this.codigo = codigo;
        this.nombre = nombre;
        this.Precioarriendo = Precioarriendo;
        this.stock = stock;
        this.descripcion = descripcion;
        this.imagen = imagen;
        this.activo = activo;
    }

   

    public Servicio(int id, String codigo, String nombre, double PrecioVenta, int stock) {
        this.ids = id;
        this.codigo = codigo;
        this.nombre = nombre;
        this.Precioarriendo = Precioarriendo;
        this.stock = stock;
    }

    public int getIds() {
        return ids;
    }

    public void setIds(int ids) {
        this.ids = ids;
    }

    public int getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(int categoriaId) {
        this.categoriaId = categoriaId;
    }

    public String getCategoriaNombre() {
        return categoriaNombre;
    }

    public void setCategoriaNombre(String categoriaNombre) {
        this.categoriaNombre = categoriaNombre;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecioarriendo() {
        return Precioarriendo;
    }

    public void setPrecioarriendo(double Precioarriendo) {
        this.Precioarriendo = Precioarriendo;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }




    


    

    

   

   

    

    


}
