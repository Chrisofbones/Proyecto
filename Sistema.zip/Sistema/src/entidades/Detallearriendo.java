/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author cristiangajardo
 */
public class Detallearriendo {
    private int id;
    private int ArriendoId;
    private int servicioId;
    private String Serviciocodigo;
    private String Servicionomnbre;
    private String hora;
    private int cantidad;//cantidad de servicios
    private double total;

    public Detallearriendo() {
    }

    public Detallearriendo(int id, int ArriendoId, int servicioId, String Serviciocodigo, String Servicionomnbre, String hora, int cantidad, double total) {
        this.id = id;
        this.ArriendoId = ArriendoId;
        this.servicioId = servicioId;
        this.Serviciocodigo = Serviciocodigo;
        this.Servicionomnbre = Servicionomnbre;
        this.hora = hora;
        this.cantidad = cantidad;
        this.total = total;
    }

    public Detallearriendo(int servicioId, int cantidad, String hora, double total) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   

    

   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getArriendoId() {
        return ArriendoId;
    }

    public void setArriendoId(int ArriendoId) {
        this.ArriendoId = ArriendoId;
    }

    public int getServicioId() {
        return servicioId;
    }

    public void setServicioId(int servicioId) {
        this.servicioId = servicioId;
    }

    public String getServiciocodigo() {
        return Serviciocodigo;
    }

    public void setServiciocodigo(String Serviciocodigo) {
        this.Serviciocodigo = Serviciocodigo;
    }

    public String getServicionomnbre() {
        return Servicionomnbre;
    }

    public void setServicionomnbre(String Servicionomnbre) {
        this.Servicionomnbre = Servicionomnbre;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    

  

  

    

   

    


}
