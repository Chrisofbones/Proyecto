/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author cristiangajardo
 */
public class Usuario {
    private int id;
    private int rolId;
    private String rolnombre;
    private String nombre;
    private String email;
    private String contraseña;
    private boolean activo;

    public Usuario() {
    }

    public Usuario(int id, int rolId, String rolnombre, String nombre, String email, boolean activo) {
        this.id = id;
        this.rolId = rolId;
        this.rolnombre = rolnombre;
        this.nombre = nombre;
        this.email = email;
        this.activo = activo;
    }





    public Usuario(int id, int rolId, String rolnombre, String nombre, String email, String contraseña, boolean activo) {
        this.id = id;
        this.rolId = rolId;
        this.rolnombre = rolnombre;
        this.nombre = nombre;
        this.email = email;
        this.contraseña = contraseña;
        this.activo = activo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRolId() {
        return rolId;
    }

    public void setRolId(int rolId) {
        this.rolId = rolId;
    }

    public String getRolnombre() {
        return rolnombre;
    }

    public void setRolnombre(String rolnombre) {
        this.rolnombre = rolnombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getemail() {
        return email;
    }

    public void setemail(String correo) {
        this.email = email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    

    

}
