/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

/**
 *
 * @author cristiangajardo
 */
public class Rol {
    private int id;
    private String nombre;
    private String Descripcion;

    public Rol() {
    }

    public Rol(int id, String nombre, String Descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.Descripcion = Descripcion;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return Descripcion;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setDescripcion(String Descripcion) {
        this.Descripcion = Descripcion;
    }

public String toString() {
        return nombre;
    }

 }
