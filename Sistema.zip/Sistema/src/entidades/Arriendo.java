 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entidades;

import java.util.Date;
import java.util.List;

/**
 *
 * @author cristiangajardo
 */
public class Arriendo {
    private int id;
    private int usuarioId;
    private String usuarionombre;
    private int personaId;
    private String personaNombre;
    private String ubicacion;
    private Date fecha;
    private String obs;
    private List<Detallearriendo> detalles;

    public Arriendo() {
    }

    public Arriendo(int id, int usuarioId, String usuarionombre, int personaId, String personaNombre, String ubicacion, Date fecha, String obs, List<Detallearriendo> detalles) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.usuarionombre = usuarionombre;
        this.personaId = personaId;
        this.personaNombre = personaNombre;
        this.ubicacion = ubicacion;
        this.fecha = fecha;
        this.obs = obs;
        this.detalles = detalles;
    }

    public Arriendo(int id, int usuarioId, String usuarionombre, int personaId, String personaNombre, String ubicacion, Date fecha, String obs) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.usuarionombre = usuarionombre;
        this.personaId = personaId;
        this.personaNombre = personaNombre;
        this.ubicacion = ubicacion;
        this.fecha = fecha;
        this.obs = obs;
    }

  

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUsuarioId() {
        return usuarioId;
    }

    public void setUsuarioId(int usuarioId) {
        this.usuarioId = usuarioId;
    }

    public String getUsuarionombre() {
        return usuarionombre;
    }

    public void setUsuarionombre(String usuarionombre) {
        this.usuarionombre = usuarionombre;
    }

    public int getPersonaId() {
        return personaId;
    }

    public void setPersonaId(int personaId) {
        this.personaId = personaId;
    }

    public String getPersonaNombre() {
        return personaNombre;
    }

    public void setPersonaNombre(String personaNombre) {
        this.personaNombre = personaNombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public List<Detallearriendo> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<Detallearriendo> detalles) {
        this.detalles = detalles;
    }

    

    

    



}
